# Ders Mesaj Paneli (Frontend)

## Vercel Ortam Değişkenleri
- `VITE_ACCESS_CODE` : Mentorların gireceği erişim kodu (örn: 2025panel)
- `VITE_API_BASE` : (İleride) backend URL'i, örn: https://ders-backend.onrender.com

## Lokal Geliştirme (istersen)
npm install
npm run dev
